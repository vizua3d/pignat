export const publicToken = "public_VCUZStQnCAbK-JAz";
export const mainSceneUUID = "4325b6f8-1a88-4506-9b6b-edbe5c7eac95";

export const youtubeVideo = {
    id: "faeT9MF1OWQ",
    timeInSecToLabelName: {
        41:             "Overview",
        55:             "Bouilleur",
        [60+16]:        "MiseSousTension",
        [60+36]:        "ExplicationDalleDoutons",
        [60+40]:        "Marche",
        [(2*60)+2]:     "BoutonnerieAlarme",
        [(2*60)+12]:    "ReglageDebitEauFroide",
        [(2*60)+26]:    "AlarmeDebitEauFroide",
        [(2*60)+30]:    "FermetureBouilleur",
        [(3*60)+18]:    "DemarrageChauffeDalle",
        [(3*60)+23]:    "DemarrageChauffebouilleur",
        [(3*60)+29]:    "ChangementConsigne",
        [(3*60)+36]:    "Ebullition",
        [(3*60)+51]:    "MiseEnRegime",
        [(5*60)+51]:    "TeteReflux"
    }
};
